package com.ezeu.app;

import java.util.Scanner;

public class CoffeMenu {

	public static void main(String[] args) {

		//Declaring Scanners to take user inputs
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		
		Coffee f ;
		int ch = 0;
		int n = 0;
		
		try {
           
			while(ch != 5) {
				
				System.out.println("Coffee Menu");
				System.out.println("press 1 for Darkroast Coffee");
				System.out.println("press 2 to select Decaf coffee");
				System.out.println("press 3 to select HouseBlend");
				System.out.println("press 4 to select expresso");
				System.out.println("press 5 to exit");
				
				while(! sc.hasNextInt()) {
					
					System.out.println("enter int inputs");
					
					sc.next();
				}
				
				ch = sc.nextInt();
				
				System.out.println("choice = "+ch);
				
		                  switch(ch) {
				
	         	        case 1 : 
	         		        System.out.println("you selected darkroast");
	         		        System.out.println("enter number of cups you want");
				        n = sc1.nextInt();
                                        f = new DarkRoast(true,n);
  	         	                System.out.println(f.getDescription());
  	         	    
	         	                break;
	         	    
	         	       case 2 :
	         		       System.out.println("you selelcted decaf");
	         		       System.out.println("enter number of cups you want");
				       n = sc1.nextInt();
	         		       f = new Decaf(n);
	         		       System.out.println(f.getDescription());
	         		
	         		       break;
	         		
	         	       case 3 : 
	         		      System.out.println("you selected houseblend");
	         		      System.out.println("enter number of cups you want");
				      n = sc1.nextInt();
	         		      f = new HouseBlend(true , n);
	         		      System.out.println(f.getDescription());
	         		
                                      break;	
                    
	         	      case 4 :
	         		     System.out.println("you selected expresso");
	         		     System.out.println("enter number of cups you want");
				     n = sc1.nextInt();
	         		     f = new Expresso(n);
	         		     System.out.println(f.getDescription());
	         		
	         		     break;
	         		
	         	     case 5 :
	         		    System.out.println("Thank You,Come Once Again..(exiting)");
	         		
	         		    break;
	         		
	                     default :
	         	            System.out.println("please enter between 1 to 5");
	         			
	         	            break;
			}
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
