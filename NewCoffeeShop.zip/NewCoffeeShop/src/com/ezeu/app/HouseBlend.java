package com.ezeu.app;

public class HouseBlend extends Coffee {

	private boolean chocolate;
	
	private static final int CHOCOLATE_COST = 20;

	public boolean isChocolate() {
		return chocolate;
	}

	public void setChocolate(boolean chocolate) {
		this.chocolate = chocolate;
	}
	
	public HouseBlend(boolean choc , int numOfCups) {
		
		this.numOfCups = numOfCups;
	   chocolate = choc;
		
		description = "HouseBlend with topping = Chocolate , COST = " + " "+cost();
	}
	
	@Override
	public int cost() {
		
		return CHOCOLATE_COST + numOfCups*20;
	}
}
