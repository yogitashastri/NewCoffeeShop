package com.ezeu.app;

public class Decaf extends Coffee {

	@Override
	public int cost() {
		return 30;
	}
	
	public Decaf(int numOfCups) {
		this.numOfCups = numOfCups;
		description = "Decaf , COST =" + " "+numOfCups*cost();
	}
}
