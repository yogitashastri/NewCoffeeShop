package com.ezeu.app;

public class DarkRoast extends Coffee {
	
	private boolean frenchVenilla;
	
	private final static int FRENCH_VENILLA_COST = 30;
	
	
	public DarkRoast(boolean fv,int numOfCups) {
		
		this.numOfCups = numOfCups;
	        this.frenchVenilla = fv;
		description = "DarkRoast with topping = FRENCH_VENILLA , COST = " +" "+numOfCups*cost();
	}
	
	@Override
	public int cost() {
		
		return FRENCH_VENILLA_COST + 20;
	}

	public boolean isFrenchVenilla() {
		return frenchVenilla;
	}

	public void setFrenchVenilla(boolean frenchVenilla) {
		this.frenchVenilla = frenchVenilla;
	}
	
	

}
