package com.ezeu.app;

public abstract class Coffee {

	String description = "";
	
        int numOfCups;
	
    //To list down all the details of the coffee
	public String getDescription() {
		
		return description;
	}
	
    //To calculate bill
	public abstract int cost();
}
