package com.ezeu.app;

public class Expresso extends Coffee {
	
	@Override
	public int cost() {
		return 38;
	}
	
	public Expresso(int numOfCups) {
		this.numOfCups = numOfCups;
		description = "Expresso , COST =" + " "+numOfCups*cost();
	}
}